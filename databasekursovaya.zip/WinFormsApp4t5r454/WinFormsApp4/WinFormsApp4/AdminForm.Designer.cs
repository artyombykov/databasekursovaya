﻿namespace WinFormsApp4
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            dateTimePicker1 = new DateTimePicker();
            textBox6 = new TextBox();
            textBox5 = new TextBox();
            textBox4 = new TextBox();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            dataGridView1 = new DataGridView();
            tabPage2 = new TabPage();
            dataGridView2 = new DataGridView();
            tabPage3 = new TabPage();
            dataGridView3 = new DataGridView();
            tabPage4 = new TabPage();
            dataGridView4 = new DataGridView();
            tabPage5 = new TabPage();
            dataGridView5 = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            textBox3 = new TextBox();
            textBox7 = new TextBox();
            textBox8 = new TextBox();
            textBox9 = new TextBox();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            textBox10 = new TextBox();
            textBox12 = new TextBox();
            textBox13 = new TextBox();
            textBox14 = new TextBox();
            dateTimePicker2 = new DateTimePicker();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            textBox11 = new TextBox();
            textBox15 = new TextBox();
            textBox17 = new TextBox();
            textBox18 = new TextBox();
            textBox19 = new TextBox();
            label16 = new Label();
            label17 = new Label();
            dateTimePicker3 = new DateTimePicker();
            label18 = new Label();
            label19 = new Label();
            label20 = new Label();
            label21 = new Label();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).BeginInit();
            tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView4).BeginInit();
            tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView5).BeginInit();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Controls.Add(tabPage4);
            tabControl1.Controls.Add(tabPage5);
            tabControl1.Location = new Point(0, 0);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(804, 455);
            tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(label6);
            tabPage1.Controls.Add(label5);
            tabPage1.Controls.Add(label4);
            tabPage1.Controls.Add(label3);
            tabPage1.Controls.Add(label2);
            tabPage1.Controls.Add(label1);
            tabPage1.Controls.Add(dateTimePicker1);
            tabPage1.Controls.Add(textBox6);
            tabPage1.Controls.Add(textBox5);
            tabPage1.Controls.Add(textBox4);
            tabPage1.Controls.Add(textBox2);
            tabPage1.Controls.Add(textBox1);
            tabPage1.Controls.Add(button3);
            tabPage1.Controls.Add(button2);
            tabPage1.Controls.Add(button1);
            tabPage1.Controls.Add(dataGridView1);
            tabPage1.Location = new Point(4, 24);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(796, 427);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Студенты";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(274, 318);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(114, 23);
            dateTimePicker1.TabIndex = 10;
            dateTimePicker1.ValueChanged += dateTimePicker1_ValueChanged;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(666, 318);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(100, 23);
            textBox6.TabIndex = 9;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(535, 318);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(100, 23);
            textBox5.TabIndex = 8;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(406, 318);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(100, 23);
            textBox4.TabIndex = 7;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(156, 318);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(100, 23);
            textBox2.TabIndex = 5;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(40, 318);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 4;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // button3
            // 
            button3.Location = new Point(232, 372);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 3;
            button3.Text = "Удалить";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.Location = new Point(137, 372);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 2;
            button2.Text = "Изменить";
            button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Location = new Point(40, 372);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 1;
            button1.Text = "Добавить";
            button1.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(8, 8);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(782, 272);
            dataGridView1.TabIndex = 0;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(button6);
            tabPage2.Controls.Add(button5);
            tabPage2.Controls.Add(button4);
            tabPage2.Controls.Add(label10);
            tabPage2.Controls.Add(label9);
            tabPage2.Controls.Add(label8);
            tabPage2.Controls.Add(label7);
            tabPage2.Controls.Add(textBox9);
            tabPage2.Controls.Add(textBox8);
            tabPage2.Controls.Add(textBox7);
            tabPage2.Controls.Add(textBox3);
            tabPage2.Controls.Add(dataGridView2);
            tabPage2.Location = new Point(4, 24);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(796, 427);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Инструкторы";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(8, 8);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.Size = new Size(782, 303);
            dataGridView2.TabIndex = 0;
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(label15);
            tabPage3.Controls.Add(label14);
            tabPage3.Controls.Add(label13);
            tabPage3.Controls.Add(label12);
            tabPage3.Controls.Add(label11);
            tabPage3.Controls.Add(dateTimePicker2);
            tabPage3.Controls.Add(textBox14);
            tabPage3.Controls.Add(textBox13);
            tabPage3.Controls.Add(textBox12);
            tabPage3.Controls.Add(textBox10);
            tabPage3.Controls.Add(dataGridView3);
            tabPage3.Location = new Point(4, 24);
            tabPage3.Name = "tabPage3";
            tabPage3.Size = new Size(796, 427);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Договор";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // dataGridView3
            // 
            dataGridView3.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView3.Location = new Point(8, 8);
            dataGridView3.Name = "dataGridView3";
            dataGridView3.Size = new Size(785, 305);
            dataGridView3.TabIndex = 0;
            // 
            // tabPage4
            // 
            tabPage4.Controls.Add(dataGridView4);
            tabPage4.Location = new Point(4, 24);
            tabPage4.Name = "tabPage4";
            tabPage4.Size = new Size(796, 427);
            tabPage4.TabIndex = 3;
            tabPage4.Text = "Машины";
            tabPage4.UseVisualStyleBackColor = true;
            // 
            // dataGridView4
            // 
            dataGridView4.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView4.Location = new Point(8, 8);
            dataGridView4.Name = "dataGridView4";
            dataGridView4.Size = new Size(785, 285);
            dataGridView4.TabIndex = 0;
            // 
            // tabPage5
            // 
            tabPage5.Controls.Add(label21);
            tabPage5.Controls.Add(label20);
            tabPage5.Controls.Add(label19);
            tabPage5.Controls.Add(label18);
            tabPage5.Controls.Add(dateTimePicker3);
            tabPage5.Controls.Add(label17);
            tabPage5.Controls.Add(label16);
            tabPage5.Controls.Add(textBox19);
            tabPage5.Controls.Add(textBox18);
            tabPage5.Controls.Add(textBox17);
            tabPage5.Controls.Add(textBox15);
            tabPage5.Controls.Add(textBox11);
            tabPage5.Controls.Add(dataGridView5);
            tabPage5.Location = new Point(4, 24);
            tabPage5.Name = "tabPage5";
            tabPage5.Size = new Size(796, 427);
            tabPage5.TabIndex = 4;
            tabPage5.Text = "Экзамены";
            tabPage5.UseVisualStyleBackColor = true;
            // 
            // dataGridView5
            // 
            dataGridView5.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView5.Location = new Point(8, 8);
            dataGridView5.Name = "dataGridView5";
            dataGridView5.Size = new Size(785, 296);
            dataGridView5.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(68, 300);
            label1.Name = "label1";
            label1.Size = new Size(34, 15);
            label1.TabIndex = 11;
            label1.Text = "ФИО";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(185, 300);
            label2.Name = "label2";
            label2.Size = new Size(18, 15);
            label2.TabIndex = 12;
            label2.Text = "ID";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(431, 300);
            label3.Name = "label3";
            label3.Size = new Size(46, 15);
            label3.TabIndex = 13;
            label3.Text = "Группа";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(515, 300);
            label4.Name = "label4";
            label4.Size = new Size(144, 15);
            label4.TabIndex = 14;
            label4.Text = "Номер и серия паспорта";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(665, 300);
            label5.Name = "label5";
            label5.Size = new Size(101, 15);
            label5.TabIndex = 15;
            label5.Text = "Номер телефона";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(287, 300);
            label6.Name = "label6";
            label6.Size = new Size(90, 15);
            label6.TabIndex = 16;
            label6.Text = "Дата рождения";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(599, 329);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(100, 23);
            textBox3.TabIndex = 10;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(439, 329);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(100, 23);
            textBox7.TabIndex = 11;
            // 
            // textBox8
            // 
            textBox8.Location = new Point(256, 329);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(100, 23);
            textBox8.TabIndex = 12;
            textBox8.TextChanged += textBox8_TextChanged;
            // 
            // textBox9
            // 
            textBox9.Location = new Point(86, 329);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(100, 23);
            textBox9.TabIndex = 13;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(117, 314);
            label7.Name = "label7";
            label7.Size = new Size(34, 15);
            label7.TabIndex = 14;
            label7.Text = "ФИО";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(299, 314);
            label8.Name = "label8";
            label8.Size = new Size(18, 15);
            label8.TabIndex = 15;
            label8.Text = "ID";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(421, 314);
            label9.Name = "label9";
            label9.Size = new Size(144, 15);
            label9.TabIndex = 16;
            label9.Text = "Номер и серия паспорта";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(599, 314);
            label10.Name = "label10";
            label10.Size = new Size(101, 15);
            label10.TabIndex = 17;
            label10.Text = "Номер телефона";
            // 
            // button4
            // 
            button4.Location = new Point(98, 376);
            button4.Name = "button4";
            button4.Size = new Size(75, 23);
            button4.TabIndex = 18;
            button4.Text = "Добавить";
            button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.Location = new Point(269, 376);
            button5.Name = "button5";
            button5.Size = new Size(75, 23);
            button5.TabIndex = 19;
            button5.Text = "Изменить";
            button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.Location = new Point(452, 376);
            button6.Name = "button6";
            button6.Size = new Size(75, 23);
            button6.TabIndex = 20;
            button6.Text = "Удалить";
            button6.UseVisualStyleBackColor = true;
            // 
            // textBox10
            // 
            textBox10.Location = new Point(52, 333);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(100, 23);
            textBox10.TabIndex = 14;
            // 
            // textBox12
            // 
            textBox12.Location = new Point(320, 333);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(100, 23);
            textBox12.TabIndex = 16;
            // 
            // textBox13
            // 
            textBox13.Location = new Point(462, 333);
            textBox13.Name = "textBox13";
            textBox13.Size = new Size(100, 23);
            textBox13.TabIndex = 17;
            // 
            // textBox14
            // 
            textBox14.Location = new Point(599, 333);
            textBox14.Name = "textBox14";
            textBox14.Size = new Size(100, 23);
            textBox14.TabIndex = 18;
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.Location = new Point(177, 333);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(114, 23);
            dateTimePicker2.TabIndex = 19;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(93, 315);
            label11.Name = "label11";
            label11.Size = new Size(18, 15);
            label11.TabIndex = 20;
            label11.Text = "ID";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(217, 316);
            label12.Name = "label12";
            label12.Size = new Size(32, 15);
            label12.TabIndex = 21;
            label12.Text = "Дата";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(471, 315);
            label13.Name = "label13";
            label13.Size = new Size(84, 15);
            label13.TabIndex = 22;
            label13.Text = "ФИО студента";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(593, 316);
            label14.Name = "label14";
            label14.Size = new Size(106, 15);
            label14.TabIndex = 23;
            label14.Text = "ФИО инструктора";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(350, 315);
            label15.Name = "label15";
            label15.Size = new Size(35, 15);
            label15.TabIndex = 24;
            label15.Text = "Цена";
            // 
            // textBox11
            // 
            textBox11.Location = new Point(27, 336);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(100, 23);
            textBox11.TabIndex = 14;
            // 
            // textBox15
            // 
            textBox15.Location = new Point(154, 336);
            textBox15.Name = "textBox15";
            textBox15.Size = new Size(100, 23);
            textBox15.TabIndex = 15;
            // 
            // textBox17
            // 
            textBox17.Location = new Point(416, 336);
            textBox17.Name = "textBox17";
            textBox17.Size = new Size(100, 23);
            textBox17.TabIndex = 17;
            // 
            // textBox18
            // 
            textBox18.Location = new Point(545, 336);
            textBox18.Name = "textBox18";
            textBox18.Size = new Size(100, 23);
            textBox18.TabIndex = 18;
            // 
            // textBox19
            // 
            textBox19.Location = new Point(665, 336);
            textBox19.Name = "textBox19";
            textBox19.Size = new Size(100, 23);
            textBox19.TabIndex = 19;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(27, 318);
            label16.Name = "label16";
            label16.Size = new Size(84, 15);
            label16.TabIndex = 23;
            label16.Text = "ФИО студента";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(154, 318);
            label17.Name = "label17";
            label17.Size = new Size(106, 15);
            label17.TabIndex = 24;
            label17.Text = "ФИО инструктора";
            // 
            // dateTimePicker3
            // 
            dateTimePicker3.Location = new Point(277, 336);
            dateTimePicker3.Name = "dateTimePicker3";
            dateTimePicker3.Size = new Size(114, 23);
            dateTimePicker3.TabIndex = 25;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(316, 318);
            label18.Name = "label18";
            label18.Size = new Size(32, 15);
            label18.TabIndex = 26;
            label18.Text = "Дата";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(434, 318);
            label19.Name = "label19";
            label19.Size = new Size(55, 15);
            label19.TabIndex = 27;
            label19.Text = "Машина";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(538, 318);
            label20.Name = "label20";
            label20.Size = new Size(107, 15);
            label20.TabIndex = 28;
            label20.Text = "Отделение ГИБДД";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(682, 318);
            label21.Name = "label21";
            label21.Size = new Size(60, 15);
            label21.TabIndex = 29;
            label21.Text = "Результат";
            // 
            // AdminForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(tabControl1);
            Name = "AdminForm";
            Text = "Администратор";
            Load += AdminForm_Load;
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).EndInit();
            tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView4).EndInit();
            tabPage5.ResumeLayout(false);
            tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView5).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private TabPage tabPage3;
        private TabPage tabPage4;
        private TabPage tabPage5;
        private DataGridView dataGridView1;
        private DataGridView dataGridView2;
        private DataGridView dataGridView3;
        private DataGridView dataGridView4;
        private DataGridView dataGridView5;
        private TextBox textBox1;
        private Button button3;
        private Button button2;
        private Button button1;
        private TextBox textBox6;
        private TextBox textBox5;
        private TextBox textBox4;
        private TextBox textBox2;
        private DateTimePicker dateTimePicker1;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox textBox9;
        private TextBox textBox8;
        private TextBox textBox7;
        private TextBox textBox3;
        private Label label7;
        private Button button6;
        private Button button5;
        private Button button4;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label14;
        private Label label13;
        private Label label12;
        private Label label11;
        private DateTimePicker dateTimePicker2;
        private TextBox textBox14;
        private TextBox textBox13;
        private TextBox textBox12;
        private TextBox textBox10;
        private Label label15;
        private TextBox textBox19;
        private TextBox textBox18;
        private TextBox textBox17;
        private TextBox textBox15;
        private TextBox textBox11;
        private Label label16;
        private Label label18;
        private DateTimePicker dateTimePicker3;
        private Label label17;
        private Label label21;
        private Label label20;
        private Label label19;
    }
}