﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp4
{
    public partial class StudentForm : Form
    {
        public StudentForm()
        {
            InitializeComponent();
            this.Text = "Студент";

            // Создаем элементы управления
            Label welcomeLabel = new Label
            {
                Text = "Добро пожаловать, Cтудент",
                AutoSize = true,
                Location = new System.Drawing.Point(30, 30)
            };

            Button exitButton = new Button
            {
                Text = "Выйти",
                Location = new System.Drawing.Point(30, 70)
            };
            exitButton.Click += ExitButton_Click;

            // Добавляем элементы на форму
            Controls.Add(welcomeLabel);
            Controls.Add(exitButton);
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            // Закрыть приложение
            Application.Exit();
        }


        private void StudentForm_Load(object sender, EventArgs e)
        {

        }
    }
}

